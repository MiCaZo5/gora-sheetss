/**
 * Гора, упавшая со звезды: листы героев (gora-sheets)
 * Для Foundry VTT 14 и системы dnd5e.
 *
 * Что делает модуль:
 *  1. Регистрирует лист героя «Гора: лист героя» (наследник листа dnd5e) с темой «Акварельный свиток».
 *  2. Добавляет в заголовок листа кнопки «Цвет героя» и «Воспоминания».
 *  3. Показывает в заголовке индикатор общего Ветра (0–10).
 *  4. Даёт отдельное окно «Воспоминания» (три слота на героя, данные в флагах актора).
 */

const MOD = 'gora-sheets';

const ACCENTS = [
  { id: 'ember', hex: '#c8763a' },
  { id: 'moss', hex: '#6b8f4e' },
  { id: 'ice', hex: '#5b7bd5' },
  { id: 'lilac', hex: '#9a6fd0' },
  { id: 'ochre', hex: '#c9a227' }
];

const MEMORY_STATES = ['sealed', 'open', 'used'];
const ROMAN = ['I', 'II', 'III'];

const { ApplicationV2, HandlebarsApplicationMixin, DialogV2 } = foundry.applications.api;

/* -------------------------------------------------------------------------- */
/*  Ветер                                                                      */
/* -------------------------------------------------------------------------- */

function getWind() {
  return Number(game.settings.get(MOD, 'wind')) || 0;
}

async function setWind(value, reason = '') {
  if (!game.user.isGM) return;
  const prev = getWind();
  const next = Math.max(0, Math.min(10, Math.round(Number(value))));
  if (Number.isNaN(next) || next === prev) return;
  await game.settings.set(MOD, 'wind', next);
  const delta = (next - prev > 0 ? '+' : '') + (next - prev);
  const text = game.i18n.format('GORA.Wind.Changed', { value: next, delta });
  await ChatMessage.create({
    content: `<p><strong>${text}</strong>${reason ? `<br><em>${foundry.utils.escapeHTML(reason)}</em>` : ''}</p>`,
    speaker: { alias: 'Гора' }
  });
}

async function changeWind(delta, reason = '') {
  return setWind(getWind() + Number(delta), reason);
}

function refreshWindPills() {
  const level = getWind();
  document.querySelectorAll('.gora-wind-pill').forEach((pill) => {
    const value = pill.querySelector('.gora-wind-value');
    if (value) value.textContent = `${level}/10`;
    pill.dataset.level = level <= 2 ? 'low' : level <= 6 ? 'mid' : 'high';
  });
}

async function promptWind() {
  if (!game.user.isGM) return;
  const label = game.i18n.localize('GORA.Wind.PromptLabel');
  const value = await DialogV2.prompt({
    window: { title: game.i18n.localize('GORA.Wind.PromptTitle') },
    content: `<div class="form-group"><label>${label}</label><input type="number" name="wind" min="0" max="10" step="1" value="${getWind()}" autofocus></div>`,
    ok: {
      label: 'OK',
      callback: (event, button) => button.form.elements.wind.value
    },
    rejectClose: false
  });
  if (value !== null && value !== undefined) await setWind(value);
}

/* -------------------------------------------------------------------------- */
/*  Воспоминания                                                               */
/* -------------------------------------------------------------------------- */

function defaultMemories() {
  return [0, 1, 2].map((i) => ({ title: '', text: '', gift: '', state: i === 0 ? 'open' : 'sealed' }));
}

function getMemories(actor) {
  const stored = actor.getFlag(MOD, 'memories');
  const base = defaultMemories();
  if (!Array.isArray(stored)) return base;
  return base.map((def, i) => ({ ...def, ...(stored[i] ?? {}) }));
}

class GoraMemories extends HandlebarsApplicationMixin(ApplicationV2) {
  static DEFAULT_OPTIONS = {
    tag: 'form',
    classes: ['gora-memories'],
    position: { width: 520, height: 'auto' },
    window: { icon: 'fa-solid fa-feather-pointed', resizable: true },
    form: {
      handler: GoraMemories.#onSubmit,
      submitOnChange: true,
      closeOnSubmit: false
    },
    actions: {
      unlock: GoraMemories.#onUnlock
    }
  };

  static PARTS = {
    body: { template: `modules/${MOD}/templates/memories.hbs` }
  };

  constructor(actor, options = {}) {
    super({ id: `gora-memories-${actor.id}`, ...options });
    this.actor = actor;
  }

  get title() {
    return `${game.i18n.localize('GORA.Memories.Title')}: ${this.actor.name}`;
  }

  async _prepareContext() {
    const isGM = game.user.isGM;
    const canEdit = this.actor.isOwner;
    const memories = getMemories(this.actor).map((m, index) => {
      const sealed = m.state === 'sealed';
      return {
        ...m,
        index,
        numeral: ROMAN[index],
        sealed,
        stateClass: `is-${m.state}`,
        stateLabel: `GORA.Memories.State.${m.state}`,
        showBody: !sealed || isGM,
        canEditText: canEdit && (!sealed || isGM),
        canEditGift: isGM,
        showGift: !sealed || isGM
      };
    });
    return {
      actor: this.actor,
      isGM,
      memories,
      stateChoices: Object.fromEntries(MEMORY_STATES.map((s) => [s, `GORA.Memories.State.${s}`])),
      wind: getWind()
    };
  }

  async _onRender(context, options) {
    await super._onRender?.(context, options);
    const accent = ACCENTS.find((a) => a.id === this.actor.getFlag(MOD, 'accent'));
    if (accent) this.element.style.setProperty('--gora-accent', accent.hex);
    else this.element.style.removeProperty('--gora-accent');
  }

  static async #onSubmit(event, form, formData) {
    const data = foundry.utils.expandObject(formData.object);
    const isGM = game.user.isGM;
    const current = getMemories(this.actor);
    const next = current.map((m, i) => {
      const f = data.memories?.[i] ?? {};
      const out = { ...m };
      if (m.state !== 'sealed' || isGM) {
        if (this.actor.isOwner || isGM) {
          if (typeof f.title === 'string') out.title = f.title;
          if (typeof f.text === 'string') out.text = f.text;
        }
      }
      if (isGM) {
        if (typeof f.gift === 'string') out.gift = f.gift;
        if (MEMORY_STATES.includes(f.state)) out.state = f.state;
      }
      return out;
    });
    await this.actor.setFlag(MOD, 'memories', next);
  }

  static async #onUnlock(event, target) {
    if (!game.user.isGM) return;
    const index = Number(target.dataset.index);
    const memories = getMemories(this.actor);
    if (!memories[index]) return;
    memories[index].state = 'open';
    await this.actor.setFlag(MOD, 'memories', memories);
  }
}

/** Открыть (или поднять) окно воспоминаний актора. */
function openMemories(actor) {
  const existing = foundry.applications.instances.get(`gora-memories-${actor.id}`);
  if (existing) return existing.render({ force: true });
  return new GoraMemories(actor).render({ force: true });
}

// Перерисовываем окно, если флаги актора изменились.
Hooks.on('updateActor', (actor, changes) => {
  if (!foundry.utils.hasProperty(changes, `flags.${MOD}`)) return;
  foundry.applications.instances.get(`gora-memories-${actor.id}`)?.render();
});

/* -------------------------------------------------------------------------- */
/*  Лист героя                                                                 */
/* -------------------------------------------------------------------------- */

function applyAccent(app) {
  const accent = ACCENTS.find((a) => a.id === app.document.getFlag(MOD, 'accent'));
  if (accent) app.element.style.setProperty('--gora-accent', accent.hex);
  else app.element.style.removeProperty('--gora-accent');
}

function ensureWindPill(app) {
  const header = app.element.querySelector('.window-header');
  if (!header) return;
  let pill = header.querySelector('.gora-wind-pill');
  if (!game.settings.get(MOD, 'showWind')) {
    pill?.remove();
    return;
  }
  if (!pill) {
    pill = document.createElement('button');
    pill.type = 'button';
    pill.className = 'gora-wind-pill';
    pill.dataset.tooltip = game.i18n.localize('GORA.Wind.Tooltip');
    pill.innerHTML = `<i class="fa-solid fa-wind"></i> <span class="gora-wind-label">${game.i18n.localize('GORA.Wind.Label')}</span> <span class="gora-wind-value"></span>`;
    pill.addEventListener('click', (ev) => {
      ev.preventDefault();
      promptWind();
    });
    const title = header.querySelector('.window-title');
    if (title) title.after(pill);
    else header.prepend(pill);
  }
  refreshWindPills();
}

function makeSheet(Base) {
  return class GoraCharacterSheet extends Base {
    static DEFAULT_OPTIONS = {
      classes: ['gora-sheet'],
      actions: {
        goraAccent: GoraCharacterSheet.#onAccent,
        goraMemories: GoraCharacterSheet.#onMemories
      }
    };

    _getHeaderControls() {
      const controls = super._getHeaderControls();
      controls.push(
        {
          icon: 'fa-solid fa-feather-pointed',
          label: 'GORA.Memories.Open',
          action: 'goraMemories',
          visible: true
        },
        {
          icon: 'fa-solid fa-palette',
          label: 'GORA.Sheet.Accent',
          action: 'goraAccent',
          visible: this.document.isOwner
        }
      );
      return controls;
    }

    async _onRender(context, options) {
      await super._onRender?.(context, options);
      applyAccent(this);
      ensureWindPill(this);
    }

    static async #onMemories() {
      return openMemories(this.document);
    }

    static async #onAccent() {
      const actor = this.document;
      if (!actor.isOwner) return;
      const swatches = ACCENTS.map(
        (a) => `<span class="gora-swatch-name" style="--swatch:${a.hex}">${game.i18n.localize(`GORA.Accent.${a.id}`)}</span>`
      ).join('');
      const choice = await DialogV2.wait({
        window: { title: game.i18n.localize('GORA.Accent.Title'), classes: ['gora-accent-dialog'] },
        content: `<p>${game.i18n.localize('GORA.Accent.Hint')}</p><div class="gora-swatches">${swatches}</div>`,
        buttons: [
          ...ACCENTS.map((a) => ({
            action: a.id,
            label: game.i18n.localize(`GORA.Accent.${a.id}`),
            callback: () => a.id
          })),
          { action: 'reset', label: game.i18n.localize('GORA.Accent.Reset'), callback: () => 'reset' }
        ],
        rejectClose: false
      });
      if (!choice) return;
      if (choice === 'reset') await actor.unsetFlag(MOD, 'accent');
      else await actor.setFlag(MOD, 'accent', choice);
    }
  };
}

let sheetRegistered = false;

function tryRegisterSheet() {
  if (sheetRegistered) return;
  if (game.system.id !== 'dnd5e') return;
  const Base = globalThis.dnd5e?.applications?.actor?.CharacterActorSheet;
  if (!Base) return;
  const GoraSheet = makeSheet(Base);
  foundry.applications.apps.DocumentSheetConfig.registerSheet(Actor, MOD, GoraSheet, {
    types: ['character'],
    makeDefault: true,
    label: 'GORA.Sheet.Name'
  });
  sheetRegistered = true;
}

/* -------------------------------------------------------------------------- */
/*  Инициализация                                                              */
/* -------------------------------------------------------------------------- */

Hooks.once('init', () => {
  game.settings.register(MOD, 'wind', {
    scope: 'world',
    config: false,
    type: Number,
    default: 3,
    onChange: () => {
      refreshWindPills();
      Hooks.callAll('goraWindChanged', getWind());
    }
  });

  game.settings.register(MOD, 'showWind', {
    name: 'GORA.Settings.ShowWind.Name',
    hint: 'GORA.Settings.ShowWind.Hint',
    scope: 'client',
    config: true,
    type: Boolean,
    default: true,
    onChange: () => {
      for (const app of foundry.applications.instances.values()) {
        if (app.options?.classes?.includes('gora-sheet')) ensureWindPill(app);
      }
    }
  });

  const module = game.modules.get(MOD);
  if (module) module.api = { getWind, setWind, changeWind, openMemories, getMemories };

  tryRegisterSheet();
});

// Если класс листа dnd5e ещё не был доступен на init, пробуем позже.
Hooks.once('setup', tryRegisterSheet);

Hooks.once('ready', () => {
  tryRegisterSheet();
  if (!sheetRegistered && game.system.id === 'dnd5e' && game.user.isGM) {
    ui.notifications.warn(
      'Гора: листы героев: не найден базовый лист dnd5e (dnd5e.applications.actor.CharacterActorSheet). Проверьте версию системы dnd5e.'
    );
  }
  refreshWindPills();
});
